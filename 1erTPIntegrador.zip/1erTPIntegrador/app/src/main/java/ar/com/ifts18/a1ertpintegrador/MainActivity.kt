package ar.com.ifts18.a1ertpintegrador

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import ar.com.ifts18.a1ertpintegrador.TestActivity
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val botonTest = findViewById<Button>(R.id.btTest)
        val botonCalcular = findViewById<Button>(R.id.btCalcular)
        val botonHistorial = findViewById<Button>(R.id.btHistorial)
        val botonLegal = findViewById<Button>(R.id.btLegal)

        botonTest.setOnClickListener{
            val intent = Intent(this, TestActivity::class.java)
            startActivity(intent)
        }

        botonCalcular.setOnClickListener{ // Poner if
            val intent = Intent(this, CalcularActivity::class.java)
            startActivity(intent)
        }
        botonHistorial.setOnClickListener{
            val intent = Intent(this, HistorialActivity::class.java)
            startActivity(intent)
        }

        botonLegal.setOnClickListener{
            val intent = Intent(this, LegalActivity::class.java)
            startActivity(intent)
        }

    }
}
